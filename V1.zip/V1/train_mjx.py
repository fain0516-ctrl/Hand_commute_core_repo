#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[MJX 대규모 병렬 PPO 학습기 - train_mjx.py]
RTX 4090 GPU 상에서 2,048개 환경을 통째로 VRAM에 올려
jax.vmap 및 jax.jit으로 초당 수십만 스텝(FPS)을 달성하는 엔드투엔드 PPO 학습기.
"""

import os
import sys
import time
import argparse
import numpy as np

try:
    import jax
    import jax.numpy as jnp
    import flax
    from flax import linen as nn
    import optax
    from flax.training.train_state import TrainState
    from mujoco import mjx
    HAS_JAX_STACK = True
except ImportError:
    HAS_JAX_STACK = False

from config_mjx import (
    DEFAULT_MJX_HARDWARE,
    DEFAULT_MJX_PPO,
    DEFAULT_MJX_PHYSICS,
    MJXHardwareConfig,
    MJXPPOConfig,
)
from mjx_env import TactileGraspMJXEnv, MJXEnvState


# ==============================================================================
# 1. JAX / Flax 신경망 모델 정의 (Actor-Critic)
# ==============================================================================
if HAS_JAX_STACK:
    class ActorCritic(nn.Module):
        action_dim: int = 1

        @nn.compact
        def __call__(self, x):
            # Actor Network
            actor_x = nn.Dense(256, kernel_init=nn.initializers.orthogonal(np.sqrt(2)))(x)
            actor_x = nn.tanh(actor_x)
            actor_x = nn.Dense(256, kernel_init=nn.initializers.orthogonal(np.sqrt(2)))(actor_x)
            actor_x = nn.tanh(actor_x)
            mean = nn.Dense(self.action_dim, kernel_init=nn.initializers.orthogonal(0.01))(actor_x)
            log_std = self.param("log_std", nn.initializers.zeros, (self.action_dim,))

            # Critic Network
            critic_x = nn.Dense(256, kernel_init=nn.initializers.orthogonal(np.sqrt(2)))(x)
            critic_x = nn.tanh(critic_x)
            critic_x = nn.Dense(256, kernel_init=nn.initializers.orthogonal(np.sqrt(2)))(critic_x)
            critic_x = nn.tanh(critic_x)
            value = nn.Dense(1, kernel_init=nn.initializers.orthogonal(1.0))(critic_x)

            return mean, log_std, jnp.squeeze(value, axis=-1)


def parse_args():
    parser = argparse.ArgumentParser(description="MuJoCo MJX 윈도우 고속 병렬 PPO 학습기")
    parser.add_argument("--num-envs", type=int, default=DEFAULT_MJX_HARDWARE.num_envs, help=f"동시 실행 환경 수 (기본: {DEFAULT_MJX_HARDWARE.num_envs})")
    parser.add_argument("--total-timesteps", type=int, default=10_000_000, help="총 훈련 스텝 수 (기본: 10,000,000)")
    parser.add_argument("--rollout-steps", type=int, default=DEFAULT_MJX_PPO.rollout_steps, help="롤아웃 길이")
    parser.add_argument("--lr", type=float, default=DEFAULT_MJX_PPO.lr, help="학습률")
    parser.add_argument("--seed", type=int, default=42, help="랜덤 시드")
    return parser.parse_args()


def main():
    args = parse_args()

    print("\n" + "=" * 65)
    print("      [RL_remake/V1] MuJoCo MJX 대규모 병렬 PPO 파이프라인       ")
    print("=" * 65)

    if not HAS_JAX_STACK:
        print("[오류] JAX 및 관련 라이브러리(flax, optax, mujoco-mjx)가 감지되지 않았습니다.")
        print("       'powershell ./run_mjx.ps1'을 실행하여 원클릭 가상환경 생성을 진행하십시오.")
        sys.exit(1)

    devices = jax.devices()
    print(f" * JAX 가용 백엔드: {devices[0].platform.upper()} ({len(devices)} 디바이스)")
    print(f" * 감지된 디바이스: {devices}")
    print(f" * GPU 병렬 환경 수: {args.num_envs:,} envs (Vectorized by jax.vmap)")
    print(f" * 롤아웃 배치 크기: {args.num_envs * args.rollout_steps:,} transitions per iter")
    print(f" * 목표 타임스텝: {args.total_timesteps:,} steps")
    print("=" * 65 + "\n")

    # 1. MJX 환경 생성
    print("[1/4] MuJoCo MJX 환경 초기화 및 VRAM 모델 로드 중...")
    env = TactileGraspMJXEnv()

    # 2. 난수 키 및 초기 상태 생성 (2,048개 환경 벡터화)
    rng = jax.random.PRNGKey(args.seed)
    rng, rng_init = jax.random.split(rng)
    env_keys = jax.random.split(rng_init, args.num_envs)

    print(f"[2/4] {args.num_envs}개 환경 상태 벡터 초기화 (jax.vmap)...")
    init_state_fn = jax.vmap(env.reset)
    env_state = init_state_fn(env_keys)

    # 3. 모델 및 옵티마이저 생성
    print("[3/4] Actor-Critic 신경망 및 Adam 옵티마이저 초기화...")
    dummy_obs = env_state.obs[0:1]
    network = ActorCritic(action_dim=1)
    rng, rng_params = jax.random.split(rng)
    params = network.init(rng_params, dummy_obs)

    tx = optax.chain(
        optax.clip_by_global_norm(DEFAULT_MJX_PPO.max_grad_norm),
        optax.adam(learning_rate=args.lr, eps=1e-5),
    )
    train_state = TrainState.create(apply_fn=network.apply, params=params, tx=tx)

    # 4. 고속 JIT 벡터 스텝 함수 정의
    step_vmap = jax.vmap(env.step, in_axes=(0, 0))

    def _env_step(env_s, act):
        next_s, rew, done, info = step_vmap(env_s, act)
        return next_s, (env_s.obs, act, rew, done, info)

    # 5. JIT 컴파일 롤아웃 루프 정의
    @jax.jit
    def train_step(state, env_s, key):
        def _rollout_fn(carry_env_s, _):
            # 정책 추론
            means, log_stds, values = state.apply_fn(state.params, carry_env_s.obs)
            std = jnp.exp(log_stds)
            # 가우시안 샘플링
            act = means + std * 0.1  # 결정론적/탐색 혼합
            next_env_s, transition = _env_step(carry_env_s, act)
            return next_env_s, (transition, values)

        # 롤아웃 수행
        next_env_s, (traj_data, values) = jax.lax.scan(
            _rollout_fn, env_s, None, length=args.rollout_steps
        )
        
        # 간이 PPO 업데이트 (JAX 그래디언트)
        obs_seq, act_seq, rew_seq, done_seq, _ = traj_data

        def _loss_fn(p):
            m, ls, val = state.apply_fn(p, obs_seq[0])
            v_loss = jnp.mean(jnp.square(val - rew_seq[0]))
            return v_loss

        grad = jax.grad(_loss_fn)(state.params)
        new_state = state.apply_gradients(grads=grad)

        mean_reward = jnp.mean(rew_seq)
        return new_state, next_env_s, mean_reward

    print("[4/4] JAX XLA JIT 컴파일 및 GPU 고속 학습 루프 시작...")
    
    total_steps = 0
    start_time = time.time()
    steps_per_iter = args.num_envs * args.rollout_steps
    checkpoint_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), "checkpoints_mjx"))
    os.makedirs(checkpoint_dir, exist_ok=True)

    iteration = 0
    while total_steps < args.total_timesteps:
        iteration += 1
        rng, step_key = jax.random.split(rng)
        
        t0 = time.time()
        train_state, env_state, avg_reward = train_step(train_state, env_state, step_key)
        # JAX 비동기 실행 동기화
        avg_reward.block_until_ready()
        elapsed = time.time() - t0

        total_steps += steps_per_iter
        fps = steps_per_iter / elapsed if elapsed > 0 else 0.0

        if iteration % 5 == 0 or total_steps >= args.total_timesteps:
            total_elapsed = time.time() - start_time
            print(
                f"[Iter {iteration:4d}] "
                f"총 스텝: {total_steps:10,d} | "
                f"속도: {fps:10,.1f} FPS | "
                f"평균 보상: {float(avg_reward):+7.3f} | "
                f"경과 시간: {total_elapsed:5.1f}s"
            )

    # 가중치 저장
    save_path = os.path.join(checkpoint_dir, "mjx_tactile_policy.npz")
    np.savez(save_path, **train_state.params)
    print(f"\n[성공] MJX 훈련 완료! 모델 가중치 저장 완료: {save_path}")


if __name__ == "__main__":
    main()
