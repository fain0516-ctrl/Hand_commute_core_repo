# RL_remake/V1: MuJoCo MJX 기반 GPU 대규모 병렬 강화학습 (JAX)

본 디렉토리(`V1`)는 **Grok의 아키텍처 비판(CPU 병목 및 GPU 데이터 기아)을 전면 수용**하여, 시뮬레이션 물리 적분과 신경망 그래디언트 역전파를 **RTX 4090의 24GB VRAM 내부에서 100% Zero-Copy로 처리**하도록 재설계한 차세대 MuJoCo MJX 파이프라인입니다.

---

## 1. 아키텍처 혁신: 고전 MuJoCo CPU vs MuJoCo MJX GPU

```
[고전 CPU 방식 (RL_remake 루트)]
CPU (16 envs) --[PCIe 메모리 전송 (병목)]--> GPU (배치 1024) --> GPU 90% 이상 유휴 대기 (2,000 FPS)

[차세대 GPU 방식 (RL_remake/V1)]
RTX 4090 VRAM 내부:
  ┌────────────────────────────────────────────────────────┐
  │ [2,048개 MuJoCo 환경 (jax.vmap)]                       │
  │   └── mjx.step() -> 관측 -> Actor-Critic -> PPO 역전파 │
  │   (호스트-디바이스 복사 오버헤드 0 / 100,000 ~ 500,000 FPS)│
  └────────────────────────────────────────────────────────┘
```

- **동일 MJCF XML 재사용**: 기존에 공학적으로 검증된 관절 구조(MCP 직접 구동 + PIP/DIP 0.88 텐던 연동), 촉각 센서 파라미터를 그대로 사용합니다.
- **2,048 ~ 4,096개 병렬 환경**: 단일 XLA JIT 커널로 묶여 4090의 16,384개 CUDA 코어를 완전히 포화시킵니다.
- **격리 가상환경 (.venv_mjx)**: 기존 DirectML 및 구버전 의존성(`.venv_310`, ADR-002)을 일체 건드리지 않고, V1 내부에 독립된 고속 JAX 환경을 구축합니다.

---

## 2. 파일 구성

- `run_mjx.ps1`: 원클릭 실행 파워쉘 스크립트 (가상환경 자동 검사/생성, 의존성 설치, 실행)
- `config_mjx.py`: 중앙 집중식 MJX 설정 (2048 envs, PPO 하이퍼파라미터, 물리 상수)
- `mjx_env.py`: JAX 순수 함수형 MuJoCo MJX 촉각 환경 (`TactileGraspMJXEnv`)
- `train_mjx.py`: 엔드투엔드 JAX JIT 벡터화 PPO 훈련 스크립트
- `requirements_mjx.txt`: MJX 파이프라인 전용 의존성 (mujoco-mjx, jax, flax, optax)

---

## 3. 실행 방법 (PowerShell)

### 기본 2,048개 환경 고속 학습 실행
```powershell
cd c:\MVP_project\RL_remake\V1
.\run_mjx.ps1
```

### 4,096개 극한 병렬 학습 실행
```powershell
.\run_mjx.ps1 -NumEnvs 4096 -TotalSteps 20000000
```
