<#
.SYNOPSIS
    MuJoCo MJX 대규모 병렬 PPO 원클릭 실행 스크립트 (Windows PowerShell)

.DESCRIPTION
    - 전용 격리 가상환경(.venv_mjx) 자동 생성 및 무결점 관리 (기존 .venv_310 간섭 원천 차단)
    - JAX / MuJoCo MJX / Flax 의존성 자동 확인 및 설치
    - RTX 4090 24GB VRAM에 2,048개 환경을 통째로 올리는 train_mjx.py 즉각 구동

.EXAMPLE
    .\run_mjx.ps1
    .\run_mjx.ps1 -NumEnvs 4096 -TotalSteps 20000000
#>

param (
    [int]$NumEnvs = 4096,
    [int]$TotalSteps = 10000000,
    [switch]$Help
)

if ($Help) {
    Get-Help $MyInvocation.MyCommand.Path -Detailed
    exit 0
}

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "     [RL_remake/V1] MuJoCo MJX 고성능 병렬 학습기 구동기     " -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan

# 1. Python 3.10 인터프리터 탐색
$PythonCmd = ""
if (Get-Command py -ErrorAction SilentlyContinue) {
    $PythonCmd = "py -3.10"
} elseif (Get-Command python -ErrorAction SilentlyContinue) {
    $PythonCmd = "python"
} else {
    Write-Host "[오류] 시스템에 Python이 설치되어 있지 않습니다." -ForegroundColor Red
    exit 1
}

# 2. V1 전용 독립 가상환경 (.venv_mjx) 확인 및 생성
$VenvDir = Join-Path $ScriptDir ".venv_mjx"
$VenvPython = Join-Path $VenvDir "Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Host "[1/3] V1 전용 독립 가상환경(.venv_mjx)을 생성합니다..." -ForegroundColor Yellow
    Write-Host "      (기존 .venv_310 패키지 충돌 방지 및 ADR-002 준수)" -ForegroundColor Gray
    Invoke-Expression "$PythonCmd -m venv `"$VenvDir`""
    
    Write-Host "[2/3] MJX 필수 패키지를 설치합니다 (mujoco, mujoco-mjx, jax, flax, optax)..." -ForegroundColor Yellow
    & "$VenvPython" -m pip install --upgrade pip
    & "$VenvPython" -m pip install -r (Join-Path $ScriptDir "requirements_mjx.txt")
} else {
    Write-Host "[1/3] 기존 MJX 전용 가상환경(.venv_mjx) 감지 완료." -ForegroundColor Green
}

# 3. JAX GPU 메모리 최적화 환경변수 설정
$env:XLA_PYTHON_CLIENT_PREALLOCATE = "false"
$env:XLA_PYTHON_CLIENT_MEM_FRACTION = "0.40"

# 4. 학습 스크립트 실행
Write-Host "[3/3] train_mjx.py 실행 시작 (병렬 환경 수: $NumEnvs)..." -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan

& "$VenvPython" (Join-Path $ScriptDir "train_mjx.py") --num-envs $NumEnvs --total-timesteps $TotalSteps

Write-Host "`n[완료] MJX 학습 스크립트가 성공적으로 종료되었습니다." -ForegroundColor Cyan
