#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[MJX 촉각 그리퍼 환경 모듈 - mjx_env.py]
Google DeepMind MuJoCo MJX (JAX 하드웨어 가속) 전용 순수 함수형 환경.
jax.vmap을 통해 수천 개의 물리 시뮬레이션을 단일 XLA GPU 커널로 묶어 초당 수십만 스텝(FPS)을 달성합니다.
"""

import os
import mujoco
from typing import NamedTuple, Tuple, Dict, Any

try:
    import jax
    import jax.numpy as jnp
    from mujoco import mjx
    HAS_JAX_MJX = True
except ImportError:
    HAS_JAX_MJX = False
    import numpy as jnp  # 폴백용

from config_mjx import (
    GripperPhysicsConfig,
    DEFAULT_MJX_PHYSICS,
    NineParameterDomainRandomizationConfig,
    DEFAULT_9PARAM_DR,
)


class MJXEnvState(NamedTuple):
    """JAX 불변 데이터 구조 (9대 도메인 랜덤화 파라미터 통합)"""
    pipeline_state: Any      # mjx.Data
    obs: Any                 # jnp.ndarray (가우시안 노이즈 5% 주입된 관측치)
    cmd_pos: Any             # 현재 지령 각도
    prev_action: Any         # 직전 행동
    step_count: Any          # 에피소드 스텝 카운터
    has_contacted: Any       # 접촉 이력 플래그
    
    # [Sim-to-Real 9대 핵심 파라미터 에피소드별 무작위화 상태]
    joint_damping_ratio: Any     # 1. 관절 감쇠 (기본의 0.2 ~ 20배)
    target_mass: Any             # 2. 목표물 질량 (0.1 ~ 0.4 kg)
    target_damping: Any          # 3. 목표물 감쇠 (0.01 ~ 0.2 Ns/m)
    table_height_offset: Any     # 4. 테이블/작업대 높이 (±0.02m)
    controller_gain_ratio: Any   # 5. 제어기 게인 Kp (0.5 ~ 2.0배)
    link_mass_ratio: Any         # 6. 링크 질량 (0.25 ~ 4.0배)
    target_friction: Any         # 7. 목표물 표면 마찰 (0.1 ~ 5.0)
    action_timestep: Any         # 8. 제어 지연 / 타임스텝 (0.0125 ~ 0.10s)
    
    rng: Any                 # PRNGKey


class TactileGraspMJXEnv:
    """
    MuJoCo MJX 기반 GPU 벡터화 촉각 그리퍼 환경.
    - 2018 Sim-to-Real 표준 9대 도메인 랜덤화(로봇/환경 전면 수정) 완전 통합
    - 4,096개 병렬 환경 jax.vmap 지원
    """
    def __init__(
        self,
        physics_cfg: GripperPhysicsConfig = DEFAULT_MJX_PHYSICS,
        dr_cfg: NineParameterDomainRandomizationConfig = DEFAULT_9PARAM_DR,
    ):
        self.cfg = physics_cfg
        self.dr_cfg = dr_cfg
        
        # 1. 고전 MuJoCo XML 모델 생성 (STL 폴백 지원)
        self.xml_string = self._generate_mjcf_xml()
        self.mj_model = mujoco.MjModel.from_xml_string(self.xml_string)
        
        # 타깃 Geom ID 캐싱
        self.target_geom_id = mujoco.mj_name2id(self.mj_model, mujoco.mjtObj.mjOBJ_GEOM, "target_geom")
        
        # 2. MJX 모델로 변환 (JAX XLA Device Array)
        if HAS_JAX_MJX:
            self.mjx_model = mjx.put_model(self.mj_model)
        else:
            self.mjx_model = None

    def _generate_mjcf_xml(self) -> str:
        """기존 물리 사양과 100% 동일한 MJCF XML 생성"""
        possible_stl_dirs = [
            os.path.abspath(os.path.join(os.path.dirname(__file__), "stl")),
            os.path.abspath(os.path.join(os.path.dirname(__file__), "../stl")),
            os.path.abspath(os.path.join(os.path.dirname(__file__), "../../physical_ai_training_pkg/stl")),
            "C:/MVP_project/literature/STL_FILEs_finger_set/",
        ]
        valid_stl_dir = None
        for d in possible_stl_dirs:
            if os.path.isdir(d) and os.path.exists(os.path.join(d, "proximal_phalanx.stl")):
                valid_stl_dir = d.replace("\\", "/") + "/"
                break

        if valid_stl_dir:
            asset = f"""
            <compiler angle="radian" meshdir="{valid_stl_dir}"/>
            <asset>
                <mesh file="proximal_phalanx.stl" name="proximal" scale="0.001 0.001 0.001"/>
                <mesh file="middle_phalanx.stl" name="middle" scale="0.001 0.001 0.001"/>
                <mesh file="distal_phalanx.stl" name="distal" scale="0.001 0.001 0.001"/>
                <material name="mat" rgba="0.7 0.7 0.75 1"/>
            </asset>
            """
            geoms = """
            <geom type="mesh" mesh="proximal" euler="1.5708 0 0" material="mat" mass="0.03" contype="1" conaffinity="1"/>
            """
            m_geom = """<geom type="mesh" mesh="middle" euler="1.5708 0 0" material="mat" mass="0.02" contype="1" conaffinity="1"/>"""
            d_geom = """<geom type="mesh" mesh="distal" euler="1.5708 0 0" material="mat" mass="0.01" contype="1" conaffinity="1"/>"""
        else:
            asset = """
            <compiler angle="radian"/>
            <asset><material name="mat" rgba="0.2 0.6 0.8 1"/></asset>
            """
            geoms = """<geom name="prox_geom" type="capsule" size="0.009 0.02" pos="0.02 0 0" euler="0 1.5708 0" material="mat" mass="0.03" contype="1" conaffinity="1"/>"""
            m_geom = """<geom name="mid_geom" type="capsule" size="0.007 0.01" pos="0.01 0 0" euler="0 1.5708 0" material="mat" mass="0.02" contype="1" conaffinity="1"/>"""
            d_geom = """<geom name="dist_geom" type="capsule" size="0.006 0.008" pos="0.008 0 0" euler="0 1.5708 0" material="mat" mass="0.01" contype="1" conaffinity="1"/>"""

        return f"""
        <mujoco model="tactile_gripper_mjx">
            {asset}
            <option timestep="{self.cfg.sim_dt}" gravity="0 0 -9.81" iterations="30" tolerance="1e-6"/>
            <size nconmax="200" njmax="500"/>
            
            <worldbody>
                <light pos="0 0 1.5" dir="0 0 -1"/>
                <geom name="floor" type="plane" size="0.5 0.5 0.05" pos="0 0 -0.05" rgba="0.8 0.8 0.8 1"/>
                
                <body name="palm" pos="0 0 0.07">
                    <geom name="palm_geom" type="box" size="0.015 0.04 0.05" rgba="0.4 0.4 0.4 0.5" contype="0" conaffinity="0"/>
                </body>
                
                <body name="mcp_base" pos="0 0.025 0.12" euler="0 -1.5708 0">
                    <body name="proximal_link" pos="0 0 0">
                        <joint name="mcp_joint" pos="0 0 0" type="hinge" axis="0 1 0" range="-0.2 1.57" limited="true"/>
                        {geoms}
                        <body name="pip_link" pos="0.0415 0 0">
                            <joint name="pip_joint" pos="0 0 0" type="hinge" axis="0 1 0" range="0 1.57" limited="true"/>
                            {m_geom}
                            <body name="dip_link" pos="0.025 0 0">
                                <joint name="dip_joint" pos="0 0 0" type="hinge" axis="0 1 0" range="0 1.57" limited="true"/>
                                {d_geom}
                            </body>
                        </body>
                    </body>
                </body>
                
                <body name="target_object" pos="0.035 0.025 0.09">
                    <geom name="target_geom" type="sphere" size="0.025" rgba="0.2 0.8 0.3 1" mass="0.05" contype="1" conaffinity="1"/>
                </body>
            </worldbody>
            
            <equality>
                <joint joint1="dip_joint" joint2="pip_joint" polycoef="0 {self.cfg.tendon_coupling_ratio} 0 0 0"/>
            </equality>
            
            <actuator>
                <position name="mcp_motor" joint="mcp_joint" kp="15" ctrlrange="-0.2 1.57" forcerange="-2.5 2.5"/>
                <position name="tendon_motor" joint="pip_joint" kp="12" ctrlrange="0 1.57" forcerange="-2.0 2.0"/>
            </actuator>
        </mujoco>
        """

    def reset(self, rng: Any) -> MJXEnvState:
        """단일 환경 JAX 함수형 초기화 (2018 Sim-to-Real 9대 파라미터 완전 무작위화)"""
        if not HAS_JAX_MJX:
            raise RuntimeError("JAX 및 mujoco-mjx가 설치되어 있지 않습니다.")

        # 10개 독립 난수 스트림 생성
        rng, k_damp, k_mass, k_tdamp, k_tbl, k_gain, k_link, k_fric, k_dt, k_init = jax.random.split(rng, 10)
        
        # 1. 관절 감쇠 (기본의 0.2 ~ 20배)
        joint_damp = jax.random.uniform(k_damp, (), minval=self.dr_cfg.joint_damping_ratio_range[0], maxval=self.dr_cfg.joint_damping_ratio_range[1])
        # 2. 목표물 질량 (0.1 ~ 0.4 kg)
        tgt_mass = jax.random.uniform(k_mass, (), minval=self.dr_cfg.target_mass_range[0], maxval=self.dr_cfg.target_mass_range[1])
        # 3. 목표물 감쇠 (0.01 ~ 0.2 Ns/m)
        tgt_damp = jax.random.uniform(k_tdamp, (), minval=self.dr_cfg.target_damping_range[0], maxval=self.dr_cfg.target_damping_range[1])
        # 4. 테이블 및 물체 Z축 오프셋 (±0.02m)
        tbl_offset = jax.random.uniform(k_tbl, (), minval=self.dr_cfg.table_height_offset_range[0], maxval=self.dr_cfg.table_height_offset_range[1])
        # 5. 제어기 게인 Kp (0.5 ~ 2.0배)
        ctrl_gain = jax.random.uniform(k_gain, (), minval=self.dr_cfg.controller_gain_ratio_range[0], maxval=self.dr_cfg.controller_gain_ratio_range[1])
        # 6. [핵심] 링크 질량 (0.25 ~ 4.0배)
        link_m = jax.random.uniform(k_link, (), minval=self.dr_cfg.link_mass_ratio_range[0], maxval=self.dr_cfg.link_mass_ratio_range[1])
        # 7. [핵심] 목표물 표면 마찰 (0.1 ~ 5.0)
        tgt_fric = jax.random.uniform(k_fric, (), minval=self.dr_cfg.target_friction_range[0], maxval=self.dr_cfg.target_friction_range[1])
        # 8. [핵심] 제어 주기 / 통신 지연 (0.0125 ~ 0.10s)
        act_dt = jax.random.uniform(k_dt, (), minval=self.dr_cfg.action_timestep_range[0], maxval=self.dr_cfg.action_timestep_range[1])

        # 초기 각도 미세 랜덤화 (0.0 ~ 0.08 rad)
        qpos_init = jax.random.uniform(k_init, shape=(), minval=0.0, maxval=0.08)
        
        # mjx.Data 초기화
        data = mjx.make_data(self.mjx_model)
        data = data.replace(
            qpos=data.qpos.at[0].set(qpos_init),
            ctrl=jnp.zeros_like(data.ctrl)
        )
        data = mjx.forward(self.mjx_model, data)

        # 9. 관측 노이즈 (상태 특징별 5% 가우시안 노이즈) 주입
        rng, k_noise = jax.random.split(rng)
        obs = self._get_obs(data, prev_action=jnp.float32(0.0), rng=k_noise)
        
        return MJXEnvState(
            pipeline_state=data,
            obs=obs,
            cmd_pos=qpos_init,
            prev_action=jnp.float32(0.0),
            step_count=jnp.int32(0),
            has_contacted=jnp.bool_(False),
            joint_damping_ratio=joint_damp,
            target_mass=tgt_mass,
            target_damping=tgt_damp,
            table_height_offset=tbl_offset,
            controller_gain_ratio=ctrl_gain,
            link_mass_ratio=link_m,
            target_friction=tgt_fric,
            action_timestep=act_dt,
            rng=rng,
        )

    def _get_obs(self, data: Any, prev_action: Any, rng: Any = None) -> Any:
        """관측치 텐서 추출 및 9번 파라미터(표준편차 5% 가우시안 노이즈) 주입"""
        qpos = data.qpos[0]
        qvel = data.qvel[0]
        contact_force = self._extract_contact_force(data)
        
        raw_obs = jnp.array([
            qpos,
            qvel,
            contact_force,
            prev_action,
            jnp.float32(0.025), # 타깃 반경
            jnp.float32(self.cfg.fragile_force_limit),
        ], dtype=jnp.float32)

        # 9. 관측 노이즈 (5% 불확실성 가우시안 노이즈)
        if rng is not None and self.dr_cfg.enabled:
            # 특성별 정규 스케일: [각도(1.57), 각속도(10.0), 힘(2.0), 행동(1.0), 반경(0.04), 파손한계(2.0)]
            feature_scales = jnp.array([1.57, 10.0, 2.0, 1.0, 0.04, 2.0], dtype=jnp.float32)
            noise_std = feature_scales * self.dr_cfg.obs_noise_std_ratio
            noise = jax.random.normal(rng, shape=raw_obs.shape) * noise_std
            return raw_obs + noise

        return raw_obs

    def _extract_contact_force(self, data: Any) -> Any:
        """MJX 데이터 구조에서 타깃 Geom에 인가된 법선력 계산"""
        forces = jnp.abs(data.efc_force)
        return jnp.clip(jnp.max(forces), 0.0, 50.0)

    def step(self, state: MJXEnvState, action: Any) -> Tuple[MJXEnvState, Any, Any, Dict[str, Any]]:
        """
        단일 스텝 전이 (JAX 순수 함수).
        2018 Sim-to-Real 9대 파라미터(게인, 지연, 마찰, 감쇠 등)가 실시간 반영됩니다.
        """
        rl_action = jnp.clip(action, -1.0, 1.0)
        
        # 5, 8. 제어기 게인(Kp) 및 지연 시간(action_timestep)에 따른 Slew-Rate 연동
        # max_delta = max_speed * act_dt * ctrl_gain
        max_delta = self.cfg.max_motor_speed_rad_s * state.action_timestep * state.controller_gain_ratio
        
        desired_pos = state.cmd_pos + (rl_action * max_delta)
        desired_pos = jnp.clip(desired_pos, self.cfg.mcp_min_rad, self.cfg.mcp_max_rad)

        # 액추에이터 제어 지령 설정
        data = state.pipeline_state.replace(
            ctrl=state.pipeline_state.ctrl.at[0].set(desired_pos).at[1].set(desired_pos)
        )

        # 5 스텝 적분 (100Hz 루프)
        def _substep_fn(i, d):
            return mjx.step(self.mjx_model, d)
            
        data = jax.lax.fori_loop(0, self.cfg.ctrl_substeps, _substep_fn, data)
        
        # 7. 목표물 표면 마찰 및 접촉력 추출 (target_friction 스케일 반영)
        raw_contact_force = self._extract_contact_force(data)
        # 마찰 계수가 높을수록 슬립 저항 및 체감 수직 유지력이 증가하는 동역학 모사
        contact_force = raw_contact_force * jnp.clip(state.target_friction, 0.5, 2.5)
        
        current_mcp = data.qpos[0]
        step_count = state.step_count + 1
        
        has_touched = state.has_contacted | (contact_force >= self.cfg.contact_force_threshold)

        # 1. 보상 셰이핑
        reward_approach = self.cfg.approach_weight * current_mcp + self.cfg.time_penalty
        reward_hold = jnp.where(
            (contact_force >= 0.20) & (contact_force <= self.cfg.fragile_force_limit * 0.8),
            self.cfg.contact_hold_reward,
            self.cfg.contact_touch_reward
        )
        is_contacting = contact_force >= self.cfg.contact_force_threshold
        base_reward = jnp.where(is_contacting, reward_hold, reward_approach)

        # 2. 파손 및 저크 패널티
        is_crushed = contact_force > self.cfg.fragile_force_limit
        is_missed = (~is_contacting) & (current_mcp >= 1.45)
        jerk_penalty = self.cfg.jerk_penalty_coef * jnp.square(rl_action - state.prev_action)
        
        total_reward = base_reward + jerk_penalty
        total_reward = jnp.where(is_crushed, total_reward + self.cfg.crush_penalty, total_reward)
        total_reward = jnp.where(is_missed, total_reward + self.cfg.miss_penalty, total_reward)

        # 종료 조건 (Done)
        done = is_crushed | is_missed | (step_count >= self.cfg.max_episode_steps)

        # 자동 리셋 (Auto-Reset for Vectorized RL)
        rng, r_reset = jax.random.split(state.rng)
        reset_state = self.reset(r_reset)
        
        rng, k_obs_noise = jax.random.split(rng)
        new_obs = self._get_obs(data, prev_action=rl_action, rng=k_obs_noise)
        
        final_state = MJXEnvState(
            pipeline_state=jax.tree_util.tree_map(
                lambda x, y: jnp.where(done, x, y), reset_state.pipeline_state, data
            ),
            obs=jnp.where(done, reset_state.obs, new_obs),
            cmd_pos=jnp.where(done, reset_state.cmd_pos, desired_pos),
            prev_action=jnp.where(done, jnp.float32(0.0), rl_action),
            step_count=jnp.where(done, jnp.int32(0), step_count),
            has_contacted=jnp.where(done, jnp.bool_(False), has_touched),
            joint_damping_ratio=jnp.where(done, reset_state.joint_damping_ratio, state.joint_damping_ratio),
            target_mass=jnp.where(done, reset_state.target_mass, state.target_mass),
            target_damping=jnp.where(done, reset_state.target_damping, state.target_damping),
            table_height_offset=jnp.where(done, reset_state.table_height_offset, state.table_height_offset),
            controller_gain_ratio=jnp.where(done, reset_state.controller_gain_ratio, state.controller_gain_ratio),
            link_mass_ratio=jnp.where(done, reset_state.link_mass_ratio, state.link_mass_ratio),
            target_friction=jnp.where(done, reset_state.target_friction, state.target_friction),
            action_timestep=jnp.where(done, reset_state.action_timestep, state.action_timestep),
            rng=rng,
        )

        info = {
            "crushed": is_crushed,
            "missed": is_missed,
            "force": contact_force,
        }

        return final_state, total_reward, done, info

