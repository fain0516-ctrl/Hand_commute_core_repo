#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
[MJX 전용 중앙 집중식 설정 모듈 - config_mjx.py]
MuJoCo MJX (JAX 기반 하드웨어 가속) 파이프라인 전용 하이퍼파라미터 및 하드웨어 설정.
RTX 4090 VRAM 내에서 수천 개의 환경(2,048 ~ 8,192 envs)을 동시 적분하기 위한 스펙 정의.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Tuple


@dataclass
class MJXHardwareConfig:
    """하드웨어 및 JAX 병렬성 설정"""
    # RTX 4090 24GB VRAM 기준 병렬 환경 수: 4096개 기본 (8192개까지 확장 가능)
    num_envs: int = 4096
    
    # JAX 백엔드 플랫폼 ('gpu' 또는 'cpu' 자동 감지)
    platform: str = "gpu"
    
    # JAX 메모리 선할당 비율 (RTX 4090 24GB 중 50% = 약 12GB 사전 확보)
    xla_mem_fraction: float = 0.50


@dataclass
class MJXPPOConfig:
    """JAX / Flax 기반 고속 PPO 하이퍼파라미터 (Vectorized JIT Pipeline)"""
    # 4096 envs * 64 rollout_steps = 262,144 transitions per iteration!
    rollout_steps: int = 64
    total_timesteps: int = 50_000_000  # 4090 MJX 기준 약 수 분 내 완주
    
    # PPO 미니배치 및 업데이트 에포크
    num_minibatches: int = 16          # 262,144 / 16 = 미니배치당 16,384 samples (4090 Tensor Core 포화)
    update_epochs: int = 4
    
    # 학습률 및 클리핑
    lr: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_eps: float = 0.2
    
    # 손실 계수
    ent_coef: float = 0.005
    vf_coef: float = 0.5
    max_grad_norm: float = 0.5
    
    # 신경망 은닉층 구조 (JAX MLP)
    hidden_dims: Tuple[int, ...] = (256, 256)


@dataclass
class GripperPhysicsConfig:
    """MuJoCo 물리 및 촉각 그리퍼 파라미터"""
    sim_dt: float = 0.002
    ctrl_substeps: int = 5
    max_episode_steps: int = 150
    
    # 모터 제약 (STS3215 스마트 서보 계승)
    max_motor_speed_rad_s: float = 6.0
    mcp_min_rad: float = -0.2
    mcp_max_rad: float = 1.57
    tendon_coupling_ratio: float = 0.88
    
    # 촉각 힘 및 파지 임계치 (단위: N)
    contact_force_threshold: float = 0.15
    desired_grasp_force: float = 0.50
    fragile_force_limit: float = 2.00
    
    # 보상 가중치
    approach_weight: float = 0.05
    time_penalty: float = -0.01
    contact_touch_reward: float = 2.0
    contact_hold_reward: float = 10.0
    crush_penalty: float = -30.0
    miss_penalty: float = -10.0
    jerk_penalty_coef: float = -0.05


@dataclass
class NineParameterDomainRandomizationConfig:
    """
    [Sim-to-Real 필수 9대 핵심 도메인 랜덤화 파라미터 규격]
    1. 관절 감쇠 (Joint Damping): 기본값의 0.2 ~ 20.0배
    2. 목표물 질량 (Target Object Mass): 0.1 ~ 0.4 kg
    3. 목표물 감쇠 (Target Object Damping): 0.01 ~ 0.2 Ns/m
    4. 테이블/작업 환경 높이 (Table / Base Height): 0.73 ~ 0.77 m (상대 오프셋 ±0.02m)
    5. 제어기 게인 (Controller Gains Kp): 기본값의 0.5 ~ 2.0배
    6. [현실 적응 핵심] 링크 질량 (Link Mass): 로봇 각 링크 기본값의 0.25 ~ 4.0배
    7. [현실 적응 핵심] 목표물 마찰 (Target Friction): 0.1 ~ 5.0
    8. [현실 적응 핵심] 행동 시간 간격 (Action Timestep / Latency): 0.0125 ~ 0.1 초
    9. [현실 적응 핵심] 관측 노이즈 (Observation Noise): 상태 특징별 표준편차의 5%
    """
    enabled: bool = True
    
    # 1. 관절 감쇠비 (Joint Damping Multiplier)
    joint_damping_ratio_range: Tuple[float, float] = (0.2, 20.0)
    
    # 2. 목표물 질량 (Target Object Mass, kg)
    target_mass_range: Tuple[float, float] = (0.1, 0.4)
    
    # 3. 목표물 감쇠 (Target Object Damping, Ns/m)
    target_damping_range: Tuple[float, float] = (0.01, 0.2)
    
    # 4. 테이블 및 물체 Z축 높이 오프셋 (Workspace / Table Height, m)
    table_height_offset_range: Tuple[float, float] = (-0.02, 0.02)
    nominal_table_height: float = 0.75  # 기준 0.75m -> 0.73 ~ 0.77m
    
    # 5. 제어기 게인 배율 (Controller Gain Kp Multiplier)
    controller_gain_ratio_range: Tuple[float, float] = (0.5, 2.0)
    
    # 6. [핵심] 링크 질량 배율 (Link Mass Multiplier)
    link_mass_ratio_range: Tuple[float, float] = (0.25, 4.0)
    
    # 7. [핵심] 표면 마찰계수 (Surface Friction)
    target_friction_range: Tuple[float, float] = (0.1, 5.0)
    
    # 8. [핵심] 제어 주기 / 통신 지연 (Action Timestep, sec)
    action_timestep_range: Tuple[float, float] = (0.0125, 0.10)
    nominal_timestep: float = 0.010
    
    # 9. [핵심] 센서 관측 노이즈 (Observation Gaussian Noise Ratio)
    obs_noise_std_ratio: float = 0.05  # 특징별 스케일의 5%


DEFAULT_MJX_HARDWARE = MJXHardwareConfig()
DEFAULT_MJX_PPO = MJXPPOConfig()
DEFAULT_MJX_PHYSICS = GripperPhysicsConfig()
DEFAULT_9PARAM_DR = NineParameterDomainRandomizationConfig()

